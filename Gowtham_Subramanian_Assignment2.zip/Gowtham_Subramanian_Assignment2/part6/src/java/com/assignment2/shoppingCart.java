/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.assignment2;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Gowtham
 */
public class shoppingCart extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    HttpSession session;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            session = request.getSession();
            String type = request.getParameter("type");
            if (type.equalsIgnoreCase("Add")) {
                String[] products = request.getParameterValues("product");
                if (products != null) {
                    if (session.getAttribute("products") != null) {
                        ArrayList<String> list = (ArrayList<String>) session.getAttribute("products");
                        for (String p : products) {
                            list.add(p);
                        }
                        session.setAttribute("products", list);
                    } else {
                        ArrayList<String> list = new ArrayList<String>();
                        for (String p : products) {
                            list.add(p);
                        }
                        session.setAttribute("products", list);
                    }
                }

                /* TODO output your page here. You may use following sample code. */
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Servlet shoppingCart</title>");
                out.println("</head>");
                out.println("<body text = darkblue>");
                out.println("<h2>The following items has been added to your cart successfully</h2>");
                if (products != null) {
                    for (String s : products) {
                        out.println("-" + s);
                        out.println("<br/>");
                    }
                }
                out.println("<br/><br/>");
                out.println("<form method='post' action='shoppingCart'>");
                out.println("<input type='submit' value='[View Shopping Cart]' style=\"background: none!important;border:none;padding:0!important;border-bottom:1px solid #444;cursor: pointer;\">");
                out.println("<input type='hidden' name='type' id='type' value='View'/>");
                
                out.println("<a href='music.jsp' target='right'>[Music Page]</a>");
                out.println("<a href='books.jsp' target='right'>[Books Page]</a>");
                out.println("<a href='computers.jsp' target='right'>[Computers Page]</a>");
                out.println("</form>");
                out.println("</body>");
                out.println("</html>");
            } else if (type.equalsIgnoreCase("View")) {
                /* TODO output your page here. You may use following sample code. */
                populateShoppingCart(out);
            } else if (type.equalsIgnoreCase("Remove")) {
                if (session.getAttribute("products") != null) {
                    ArrayList<String> list = (ArrayList<String>) session.getAttribute("products");
                    int index = Integer.parseInt(request.getParameter("item"));
                    list.remove((index - 1));
                    session.setAttribute("products", list);
                    populateShoppingCart(out);
                }
            }
        } finally {
            out.close();
        }
    }

    void populateShoppingCart(PrintWriter out) {
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Servlet shoppingCart</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<script>");
        out.println("function rm(id) {");

        out.println("document.getElementById('item').value = id;");

        out.println("}");
        out.println("</script>");
        out.println("<form method='post' action='shoppingCart'>");
        out.println("<h1>Shopping Cart</h1>");
        ArrayList<String> list = (ArrayList<String>) session.getAttribute("products");
        if (list != null && (!list.isEmpty())) {
            out.println("<h3>Items in Your Cart</h3>");
            out.println("<hr />");
            int i = 1;
            Double total = 0d;
            for (String s : list) {
                out.println(i + ". ");                
                out.print(s + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
                if (s.contains("$")) {
                    String[] s1 = s.split("\\$",2);
                    String[] s2 = s1[1].split("\\]");
                    total += Double.parseDouble(s2[0]);
                }
                out.println("<input type='submit' value='[Remove From Cart]' style=\"background: none!important;border:none;padding:0!important;border-bottom:1px solid #444;cursor: pointer;\" onClick='rm(" + i + ")' />");
                i++;
                out.println("<br />");
            }
            out.println("<hr />");
            out.println("Total : " + total);
        } else {
            out.println("<h3>No Items in Shopping Cart</h3>");
        }
        out.println("<br/><br/>");
        out.println("<input type='hidden' name='type' id='type' value='Remove'/>");
        out.println("<input type='hidden' name='item' id='item'/>");
        out.println("</form>");
        out.println("</body>");
        out.println("</html>");
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
