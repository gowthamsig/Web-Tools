import java.io.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class sample5 extends HttpServlet
{
String ans1;
String ans2;
String ans3;
String ans4;
String ans5;
String ans6;
String ans7;
String ans8;
String ans9;
String ans10;

public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException
{
 sendPage1(response);
}
public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
{
String page = request.getParameter("page");
ans1 = String.valueOf(request.getParameter("answer1"));
ans2 = String.valueOf(request.getParameter("answer2"));
ans3 = String.valueOf(request.getParameter("answer3"));
ans4 = String.valueOf(request.getParameter("answer4"));
ans5 = String.valueOf(request.getParameter("answer5"));
ans6 = String.valueOf(request.getParameter("answer6"));
ans7 = String.valueOf(request.getParameter("answer7"));
ans8 = String.valueOf(request.getParameter("answer8"));
ans9 = String.valueOf(request.getParameter("answer9"));
ans10 = String.valueOf(request.getParameter("answer10"));

if (page == null) {
sendPage1(response);
return;
}
if (page.equals("1")) {
sendPage2(response);
}
if (page.equals("2")) {
sendPage3(response);
}
if (page.equals("3")) {
sendPage4(response);
}
if (page.equals("4")) {
sendPage5(response);
}
if (page.equals("5")) {
sendPage6(response);
}
if (page.equals("6")) {
sendPage7(response);
}
if (page.equals("7")) {
sendPage8(response);
}
if (page.equals("8")) {
sendPage9(response);
}
if (page.equals("9")) {
sendPage10(response);
}
if (page.equals("10")) {
displayValues(response);
}
}
void sendPage1(HttpServletResponse response) throws IOException
{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Java Quiz</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<H2>Question 1 of 10</H2>");
out.println("<FORM METHOD='POST' action='sample5.do'>");
out.println("<INPUT TYPE=HIDDEN NAME=page VALUE=1>");
out.println("<TABLE>");
out.println("<TR>");
out.println("<TD>Which of the following is NOT a Java keyword?</TD><BR><BR>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer1' VALUE='switch'>switch</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer1' VALUE='base'>base</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer1' VALUE='super'>super</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer1' VALUE='final'>final</TD><br>");
out.println("</TR>");
out.println("</TABLE>");
out.println("<INPUT TYPE=SUBMIT VALUE=Submit>");

out.println("<INPUT TYPE='HIDDEN' NAME='answer1' VALUE="+ans1+"<br>");

out.println("</FORM>");
out.println("</CENTER>");
out.println("</BODY>");
out.println("</HTML>");
 }
 void sendPage2(HttpServletResponse response) throws IOException
{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Java Quiz</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<H2>Question 2 of 10</H2>");
out.println("<FORM METHOD='POST'>");
out.println("<INPUT TYPE=HIDDEN NAME=page VALUE=2>");
out.println("<TABLE>");
out.println("<TR>");
out.println("<TD>Which of the following is a legal modifiers for a method in an interface?</TD><BR><BR>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer2' VALUE='protected'>protected</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer2' VALUE='final'>final</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer2' VALUE='private'>private</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer2' VALUE='public'>public</TD><br>");
out.println("</TR>");
out.println("</TABLE>");
out.println("<input type='button' onclick='history.back();' value='Back'>");
out.println("<INPUT TYPE=SUBMIT VALUE=Submit>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer1' VALUE="+ans1+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer2' VALUE="+ans2+"<br>");
out.println("</FORM>");
out.println("</CENTER>");
out.println("</BODY>");
out.println("</HTML>");

}
 void sendPage3(HttpServletResponse response) throws IOException
{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Java Quiz</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<H2>Question 3 of 10</H2>");
out.println("<FORM METHOD='POST'>");
out.println("<INPUT TYPE=HIDDEN NAME=page VALUE=3>");
out.println("<TABLE>");
out.println("<TR>");
out.println("<TD>Which of the following is true for BOTH interfaces and abstract classes?</TD><BR><BR>");
out.println("</TD>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer3' VALUE='They both can contain concrete methods'>They both can contain concrete methods</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer3' VALUE='They both can contain abstract methods'>They both can contain abstract methods</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer3' VALUE='They both can contain private methods'>They both can contain private methods</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer3' VALUE='They both can contain final methods'>They both can contain final methods</TD><br>");
out.println("</TR>");
out.println("</TABLE>");
out.println("<input type='button' onclick='history.back();' value='Back'>");
out.println("<TD><INPUT TYPE=SUBMIT VALUE=Submit></TD>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer1' VALUE="+ans1+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer2' VALUE="+ans2+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer3' VALUE="+ans3+"<br>");
out.println("</FORM>");
out.println("</CENTER>");
out.println("</BODY>");
out.println("</HTML>");

}
 void sendPage4(HttpServletResponse response) throws IOException
{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Java Quiz</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<H2>Question 4 of 10</H2>");
out.println("<FORM METHOD='POST'>");
out.println("<INPUT TYPE=HIDDEN NAME=page VALUE=4>");
out.println("<TABLE>");
out.println("<TR>");
out.println("<TD>What Java5 feature results in less casting?</TD><BR><BR>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer4' VALUE='Static Imports'>Static Imports</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer4' VALUE='AutoBoxing'>AutoBoxing</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer4' VALUE='Enums'>Enums</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer4' VALUE='Generics'>Generics</TD><br>");
out.println("</TR>");
out.println("</TABLE>");
out.println("<input type='button' onclick='history.back();' value='Back'>");
out.println("<TD><INPUT TYPE=SUBMIT VALUE=Submit></TD>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer1' VALUE="+ans1+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer2' VALUE="+ans2+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer3' VALUE="+ans3+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer4' VALUE="+ans4+"<br>");

out.println("</FORM>");
out.println("</CENTER>");
out.println("</BODY>");
out.println("</HTML>");

}
 void sendPage5(HttpServletResponse response) throws IOException
{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Java Quiz</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<H2>Question 5 of 10</H2>");
out.println("<FORM METHOD='POST'>");
out.println("<INPUT TYPE=HIDDEN NAME=page VALUE=5>");
out.println("<TABLE>");
out.println("<TR>");
out.println("<TD>In what package will you find JDBC classes and interfaces?</TD><BR><BR>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer5' VALUE=' java.util'> java.util</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer5' VALUE=' java.jdbc'> java.jdbc</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer5' VALUE=' javax.persistence'> javax.persistence</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer5' VALUE=' java.sql'> java.sql</TD><br>");
out.println("</TR>");
out.println("</TABLE>");
out.println("<input type='button' onclick='history.back();' value='Back'>");
out.println("<TD><INPUT TYPE=SUBMIT VALUE=Submit></TD>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer1' VALUE="+ans1+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer2' VALUE="+ans2+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer3' VALUE="+ans3+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer4' VALUE="+ans4+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer5' VALUE="+ans5+"<br>");

out.println("</FORM>");
out.println("</CENTER>");
out.println("</BODY>");
out.println("</HTML>");

}
 void sendPage6(HttpServletResponse response) throws IOException
{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Java Quiz</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<H2>Question 6 of 10</H2>");
out.println("<FORM METHOD='POST'>");
out.println("<INPUT TYPE=HIDDEN NAME=page VALUE=6>");
out.println("<TABLE>");
out.println("<TR>");
out.println("<TD>Which of the following does not inherit from the Collection interface?</TD><BR><BR>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer6' VALUE='Set'>Set</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer6' VALUE='Queue'>Queue</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer6' VALUE='List'>List</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer6' VALUE='Map'>Map</TD><br>");
out.println("</TR>");
out.println("</TABLE>");
out.println("<input type='button' onclick='history.back();' value='Back'>");
out.println("<TD><INPUT TYPE=SUBMIT VALUE=Submit></TD>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer1' VALUE="+ans1+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer2' VALUE="+ans2+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer3' VALUE="+ans3+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer4' VALUE="+ans4+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer5' VALUE="+ans5+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer6' VALUE="+ans6+"<br>");

out.println("</FORM>");
out.println("</CENTER>");
out.println("</BODY>");
out.println("</HTML>");

}
 void sendPage7(HttpServletResponse response) throws IOException
{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Java Quiz</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<H2>Question 7 of 10</H2>");
out.println("<FORM METHOD='POST'>");
out.println("<INPUT TYPE=HIDDEN NAME=page VALUE=7>");
out.println("<TABLE>");
out.println("<TR>");
out.println("<TD>What package is the List interface defined in?</TD><BR><BR>");
out.println("<TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer7' VALUE='java.lang'>java.lang</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer7' VALUE='java.collection'>java.collection</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer7' VALUE='java.awt'>java.awt</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer7' VALUE='java.util'>java.util</TD><br>");
out.println("</TR>");
out.println("</TABLE>");
out.println("<input type='button' onclick='history.back();' value='Back'>");
out.println("<TD><INPUT TYPE=SUBMIT VALUE=Submit></TD>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer1' VALUE="+ans1+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer2' VALUE="+ans2+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer3' VALUE="+ans3+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer4' VALUE="+ans4+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer5' VALUE="+ans5+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer6' VALUE="+ans6+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer7' VALUE="+ans7+"<br>");

out.println("</FORM>");
out.println("</CENTER>");
out.println("</BODY>");
out.println("</HTML>");

}
 void sendPage8(HttpServletResponse response) throws IOException
{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Java Quiz</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<H2>Question 8 of 10</H2>");
out.println("<FORM METHOD='POST'>");
out.println("<INPUT TYPE=HIDDEN NAME=page VALUE=8>");
out.println("<TABLE>");
out.println("<TR>");
out.println("<TD>Which of the following methods is defined in the java.lang.Throwable class?</TD><BR><BR>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer8' VALUE='print()'>print()</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer8' VALUE='getMessage()'>getMessage()</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer8' VALUE='equals()'>equals()</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer8' VALUE='throw()'>throw()</TD><br>");
out.println("</TR>");
out.println("</TABLE>");
out.println("<input type='button' onclick='history.back();' value='Back'>");
out.println("<TD><INPUT TYPE=SUBMIT VALUE=Submit></TD>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer1' VALUE="+ans1+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer2' VALUE="+ans2+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer3' VALUE="+ans3+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer4' VALUE="+ans4+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer5' VALUE="+ans5+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer6' VALUE="+ans6+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer7' VALUE="+ans7+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer8' VALUE="+ans8+"<br>");

out.println("</FORM>");
out.println("</CENTER>");
out.println("</BODY>");
out.println("</HTML>");

}
 void sendPage9(HttpServletResponse response) throws IOException
{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Java Quiz</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<H2>Question 9 of 10</H2>");
out.println("<FORM METHOD='POST'>");
out.println("<INPUT TYPE=HIDDEN NAME=page VALUE=9>");
out.println("<TABLE>");
out.println("<TR>");
out.println("<TD>Which of the following exceptions is unchecked?</TD><BR><BR>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer9' VALUE='CloneNotSupportedException'>CloneNotSupportedException</TD><br>");
out.println("</TR");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer9' VALUE='ParseException'>ParseException</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer9' VALUE='RuntimeException'>RuntimeException</TD><br>");
out.println("</TR");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer9' VALUE='IOException'>IOException</TD><br>");
out.println("</TR>");
out.println("</TABLE>");
out.println("<input type='button' onclick='history.back();' value='Back'>");
out.println("<TD><INPUT TYPE=SUBMIT VALUE=Submit></TD>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer1' VALUE="+ans1+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer2' VALUE="+ans2+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer3' VALUE="+ans3+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer4' VALUE="+ans4+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer5' VALUE="+ans5+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer6' VALUE="+ans6+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer7' VALUE="+ans7+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer8' VALUE="+ans8+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer9' VALUE="+ans9+"<br>");

out.println("</FORM>");
out.println("</CENTER>");
out.println("</BODY>");
out.println("</HTML>");

}
 void sendPage10(HttpServletResponse response) throws IOException
{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Java Quiz</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<H2>Question 10 of 10</H2>");
out.println("<FORM METHOD='POST'>");
out.println("<INPUT TYPE=HIDDEN NAME=page VALUE=10>");
out.println("<TABLE>");
out.println("<TR>");
out.println("<TD>Which of the following methods are NOT defined in the java.lang.Object class?</TD><BR><BR>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer10' VALUE='equals()'>equals()</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer10' VALUE='finalize()'>finalize()</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer10' VALUE='toString()'>toString()</TD><br>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD><INPUT TYPE='radio' NAME='answer10' VALUE='clone()'>clone()</TD><br>");
out.println("</TR>");
out.println("</TABLE>");
out.println("<input type='button' onclick='history.back();' value='Back'>");
out.println("<TD><INPUT TYPE=SUBMIT VALUE=Submit></TD>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer1' VALUE="+ans1+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer2' VALUE="+ans2+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer3' VALUE="+ans3+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer4' VALUE="+ans4+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer5' VALUE="+ans5+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer6' VALUE="+ans6+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer7' VALUE="+ans7+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer8' VALUE="+ans8+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer9' VALUE="+ans9+"<br>");
out.println("<INPUT TYPE='HIDDEN' NAME='answer10' VALUE="+ans10+"<br>");

out.println("</FORM>");
out.println("</CENTER>");
out.println("</BODY>");
out.println("</HTML>");

}
void displayValues(HttpServletResponse response) throws IOException
{
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Done</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<H2>Quiz Completed</H2>");
out.println("Here are the values you have entered."); 
out.println("<TABLE>");
out.println("<TR>");
out.println("<TD>First Question: &nbsp;</TD>");
out.println("<TD>" + ans1 + "</TD>");
out.println("</TR>");
out.println("<TR><TD>Second Question: &nbsp;</TD>");
out.println("<TD>" + ans2 + "</TD>");
out.println("</TR>");
out.println("<TR>");
out.println("<TD>Third Question: &nbsp;</TD>");
out.println("<TD>" + ans3 + "</TD>");
out.println("</TR>");
out.println("<TR><TD>Fourth Question: &nbsp;</TD>");
out.println("<TD>" + ans4 + "</TD>");
out.println("</TR>");
out.println("<TR><TD>Fifth Question: &nbsp;</TD>");
out.println("<TD>" + ans5 + "</TD>");
out.println("</TR>");
out.println("<TR><TD>Sixth Question: &nbsp;</TD>");
out.println("<TD>" + ans6 + "</TD>");
out.println("</TR>");
out.println("<TR><TD>Seventh Question: &nbsp;</TD>");
out.println("<TD>" + ans7 + "</TD>");
out.println("</TR>");
out.println("<TR><TD>Eight Question: &nbsp;</TD>");
out.println("<TD>" + ans8 + "</TD>");
out.println("</TR>");
out.println("<TR><TD>Ninth Question: &nbsp;</TD>");
out.println("<TD>" + ans9 + "</TD>");
out.println("</TR>");
out.println("<TR><TD>Tenth Question: &nbsp;</TD>");
out.println("<TD>" + ans10 + "</TD>");
out.println("</TR>");
out.println("</TABLE>"); 
out.println("</CENTER>");
out.println("</BODY>");
out.println("</HTML>");
}
} 