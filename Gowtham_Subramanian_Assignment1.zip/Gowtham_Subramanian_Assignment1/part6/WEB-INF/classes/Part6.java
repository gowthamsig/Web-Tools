import java.io.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class Part6 extends HttpServlet{
public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException{
handleRequest(request, response);
}

public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException{
handleRequest(request, response);
}

public void handleRequest(HttpServletRequest request,HttpServletResponse response) throws IOException{

//1.Get all data from request

String tricare = request.getParameter("tricare");
String patientname = request.getParameter("Patient name");
String dob= request.getParameter("dob");
String address = request.getParameter("address");
String zip=  request.getParameter("zip");
String city= request.getParameter("city");
String state= request.getParameter("state");
String insurance= request.getParameter("insurance");
String phone= request.getParameter("phone");
String policy= request.getParameter("policy");
String carrier= request.getParameter("carrier");
String[] providerArr= request.getParameterValues("provider");
String date = request.getParameter("date");
String contact= request.getParameter("contact");
String[] serviceArr= request.getParameterValues("service");
String ordering= request.getParameter("ordering");
String phone1= request.getParameter("phone1");
String speciality= request.getParameter("Speciality");
String[] operationArr= request.getParameterValues("operation");
String[] admissionArr= request.getParameterValues("admission");
String inpatient= request.getParameter("inpatient");
String hcpc= request.getParameter("hcpc");
String facility= request.getParameter("facility");
String addresss= request.getParameter("addresss");
String citie= request.getParameter("citie");
String statee= request.getParameter("statee");
String zipcode= request.getParameter("zipcode");

String rendering= request.getParameter("rendering");
String addres= request.getParameter("addres");
String citiee= request.getParameter("citiee");
String stateee= request.getParameter("stateee");
String zipcodee= request.getParameter("zipcodee");


String symptom= request.getParameter("symptom");
String history= request.getParameter("history");

//2.Write back all the data 

response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<html>");
out.println("<head><title>User Info Response</title></head>");
out.println("<body>");
out.println("TRICARE ID:"+ tricare +"</br>");
out.println("Password:"+ patientname +"</br>");
out.println("Patient DOB:"+ dob +"</br>");
out.println("Patient Zipcode:"+ zip +"</br>");
out.println("Patient Address:"+ address +"</br>");
out.println("Patient City:"+ city +"</br>");
out.println("Patient State:"+ state +"</br>");
out.println("=============================================================================="+"</br>");
out.println("Other Health Insurance? :"+ insurance +"</br>");
out.println("Phone:"+ phone +"</br>");
out.println("Carrier:"+ carrier +"</br>");
out.println("Policy:"+ policy +"</br>");
out.println("=============================================================================="+"</br>");
out.println("Provider or Setting"+"</br>");
for(String provider: providerArr){
out.println(provider+"</br>");
}
out.println("Date of Service (If known) MM-DD-YYYY:"+ date +"</br>");
out.println("Point Of Contact:"+ contact +"</br>");
out.println("Service Type"+"</br>");
for(String service: serviceArr){
out.println(service+"</br>");
}
out.println("Ordering Provider:"+ ordering +"</br>");
out.println("Phone"+ phone1 +"</br>");
out.println("=============================================================================="+"</br>");
out.println("Type of Service"+"</br>");
out.println("List Speciality:"+ speciality +"</br>");
out.println("Services"+"</br>");
for(String operation: operationArr){
out.println(operation+"</br>");
}
out.println("Inpatient Admission"+"</br>");
for(String operation: operationArr){
out.println(operation+"</br>");
}
out.println("Inpatient Diagnosis code:"+ inpatient +"</br>");
out.println("=============================================================================="+"</br>");
out.println("Procedure or HCPC Code:"+ hcpc +"</br>");
out.println("=============================================================================="+"</br>");
out.println("Facility:"+ facility +"</br>");
out.println("Address:"+ addresss +"</br>");
out.println("City:"+ citie +"</br>");
out.println("State:"+ statee +"</br>");
out.println("Zipcode:"+ zipcode +"</br>");
out.println("=============================================================================="+"</br>");
out.println("Rendering Provider:"+ rendering +"</br>");
out.println("Address:"+ addres +"</br>");
out.println("City:"+ citiee +"</br>");
out.println("State:"+ stateee +"</br>");
out.println("Zipcode:"+ zipcodee +"</br>");
out.println("=============================================================================="+"</br>");
out.println("Presenting symptoms or reason for referral"+"</br>");
out.println(symptom+"</br>");
out.println("=============================================================================="+"</br>");
out.println("Pertinent history, findings and specials situations include known discharge needs if inpatient admission"+"</br>");
out.println(history+"</br>");
out.println("</body>");
out.println("</html>");
out.close();
}
}