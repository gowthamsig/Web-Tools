import java.io.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class Part5 extends HttpServlet{
public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException{
handleRequest1(request, response);
}

public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException{
handleRequest2(request, response);
}

public void handleRequest2(HttpServletRequest request,HttpServletResponse response) throws IOException{

response.setContentType("text/html");
PrintWriter out = response.getWriter();

out.println("<!DOCTYPE html>");
out.println("<html>");
out.println("<head>");
out.println("<script type='text/javascript'>");
out.println("function myFunction()");
out.println("{");
out.println("var numberOfChildren, i,j;");
out.println("numberOfChildren = document.getElementById('noOfChildren').value;");
out.println("if (isNaN(numberOfChildren) || (numberOfChildren<1))");
out.println("{");
out.println("alert('Input not valid!');");
out.println("}");
out.println("var textHTML;");
out.println("textHTML = '';");
out.println("for(i=0; i<numberOfChildren; i++)");
out.println("{");
out.println("j = i+1;");
out.println("textHTML += 'Name of child number '+j+' :<input type=\\'text\\' name=\\'childname\\' /> <br/>';");
out.println("}");
out.println("textHTML += '<input type=\\'submit\\' value = \\'Submit Query\\' >';");
out.println("document.getElementById('frm1').innerHTML = '';");
out.println("document.getElementById('frm1').innerHTML = textHTML;");
out.println("document.getElementById('btnSubmit').style.visibility = 'hidden';");

out.println("}");
out.println("</script>");
out.println("</head>");
out.println("<body>");
out.println("<form id='frm1' action='part5.do' method='post'>");
out.println("How many children do you have: <input id='noOfChildren' type='text' name='children'/><br/>");
out.println("</form>");
out.println("<button id='btnSubmit' onClick='myFunction()'>Submit</button>");

out.println("</body>");
out.println("</html>");


}


public void handleRequest1(HttpServletRequest request,HttpServletResponse response) throws IOException{
	

}
}