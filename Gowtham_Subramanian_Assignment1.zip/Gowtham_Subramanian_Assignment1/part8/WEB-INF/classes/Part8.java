import java.io.*;
import javax.servlet.http.HttpServlet;
import java.io.PrintWriter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Enumeration;
import java.io.IOException;
import com.itextpdf.text.Document;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;




public class Part8 extends HttpServlet{
public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException{
handleRequest1(request, response);
}

public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException{
handleRequest2(request, response);
}

public void handleRequest2(HttpServletRequest request,HttpServletResponse response) throws IOException{

//1.Get all data from request

String tricare = request.getParameter("tricare");
String patientname = request.getParameter("Patient name");
String dob= request.getParameter("dob");
String address = request.getParameter("address");
String zip=  request.getParameter("zip");
String city= request.getParameter("city");
String state= request.getParameter("state");
String insurance= request.getParameter("insurance");
String phone= request.getParameter("phone");
String policy= request.getParameter("policy");
String carrier= request.getParameter("carrier");
String[] providerArr= request.getParameterValues("provider");
String date = request.getParameter("date");
String contact= request.getParameter("contact");
String[] serviceArr= request.getParameterValues("service");
String ordering= request.getParameter("ordering");
String phone1= request.getParameter("phone1");
String speciality= request.getParameter("Speciality");
String[] operationArr= request.getParameterValues("operation");
String[] admissionArr= request.getParameterValues("admission");
String inpatient= request.getParameter("inpatient");
String hcpc= request.getParameter("hcpc");
String facility= request.getParameter("facility");
String addresss= request.getParameter("addresss");
String citie= request.getParameter("citie");
String statee= request.getParameter("statee");
String zipcode= request.getParameter("zipcode");

String rendering= request.getParameter("rendering");
String addres= request.getParameter("addres");
String citiee= request.getParameter("citiee");
String stateee= request.getParameter("stateee");
String zipcodee= request.getParameter("zipcodee");


String symptom= request.getParameter("symptom");
String history= request.getParameter("history");

//2.Write back all the data 

response.setContentType("application/pdf");
        try
		{	
		
            Document document=new Document();
            PdfWriter.getInstance(document, response.getOutputStream());
            document.open();
			
			
			
        Paragraph p = new Paragraph("Patient Info:");
 
        document.add(p);
 
        p = new Paragraph();
		p.add(Chunk.NEWLINE);
		p.add(Chunk.NEWLINE);
		p.add(Chunk.NEWLINE);
		
      
	
			
          
			
		Enumeration paramNames = request.getParameterNames();
		
	while(paramNames.hasMoreElements())
	{
	
		String paramName=(String)paramNames.nextElement();
		p.add(new Chunk(paramName));
		p.add(new Chunk(":   "));	
		String[] paramValues=request.getParameterValues(paramName);
		
		for(int i=0; i<paramValues.length;i++)
		{
		if(i>0)
		{
		p.add(new Chunk(", "));	
		}
		p.add(new Chunk(paramValues[i]));
		//document.add(new Paragraph(paramValues[i]+" "));
		}
		
		p.add(Chunk.NEWLINE);
		
	
	}

			document.add(p);
            document.close();
        }
		catch(Exception e)
		{
			System.out.println("");
		}
	
	
}


public void handleRequest1(HttpServletRequest request,HttpServletResponse response) throws IOException{

response.sendRedirect("form.jsp");

}
}