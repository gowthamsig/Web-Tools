import java.io.*;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class Part4 extends HttpServlet{
public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException{
handleRequest1(request, response);
}

public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException{
handleRequest2(request, response);
}

public void handleRequest1(HttpServletRequest request,HttpServletResponse response) throws IOException{

response.setContentType("text/html");
PrintWriter out = response.getWriter();

out.println("<!DOCTYPE html>");
out.println("<html>");
out.println("<head>");
out.println("<title>");
out.println("Basic HTML Form");
out.println("</title>");
out.println("</head>");
out.println("<body>");
out.println("<h4>User Information:</h4>");
out.println("<form method='post' action='part4.do'>");
out.println("Username: <input type='text' name='username'/><br/>");
out.println("Password: <input type='password' name ='password'/><br/>");
out.println("Gender:<input type='radio' name='gender' value='Male'>Male");
out.println("<input type='radio' name='gender' value='Female'>Female<br/>");
out.println("Interest: <input type='checkbox' name='interest' value= 'Reading'>Reading");
out.println("<input type='checkbox' name='interest' value= 'Writing'>Writing");
out.println("<input type='checkbox' name='interest' value= 'Sports'>Sports<br/>");
out.println("<input type='submit' value='Submit'>");
out.println("</form>");
out.println("</body>");
out.println("</html>");


}


public void handleRequest2(HttpServletRequest request,HttpServletResponse response) throws IOException{
	
// Get all data from request
	
String username = request.getParameter("username");
String password = request.getParameter("password");
String gender= request.getParameter("gender");
String[] interestArr= request.getParameterValues("interest");

//Write back all the data 

response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<html>");
out.println("<head><title>User Info Response</title></head>");
out.println("<body>");
out.println("Username:"+ username +"</br>");
out.println("Password:"+ password +"</br>");
out.println("Gender:"+ gender +"</br>");
out.println("Interest:"+"</br>");
for(String interest: interestArr){
out.println(interest+"</br>");
}

out.println("</body>");
out.println("</html>");
out.close();
}
}