/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie;

import com.movie.model.MovieDetail;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;

/**
 *
 * @author Gowtham
 */
public class MyMovieServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String movieSel = request.getParameter("movietype");
        
        String title,actor,actress,genre;
        int year;
                
        if (movieSel.equals("Add Movie")) {
            title = request.getParameter("title");
            actor = request.getParameter("actor");
            actress = request.getParameter("actress");
            genre = request.getParameter("genre");
            year = Integer.parseInt(request.getParameter("year"));
           
            try {
                
                Class.forName("com.mysql.jdbc.Driver");
                
                Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root" , "");
                
                Statement myStmt = myConn.createStatement();
                
                String sql = "insert into movie_details "
                           + " (movie_title, lead_actor, lead_actress, genre, year)"
                           + " values ('"+title+"', '"+actor+"', '"+actress+"', '"+genre+"', '"+year+"' )"; 
                
                myStmt.executeUpdate(sql);
                
            }
            catch (SQLException ex) {
            Logger.getLogger(MyMovieServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
            RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
                rd.forward(request, response);
        }
        
          else   if (movieSel.equals("Search Movie")) {
                
                ArrayList<MovieDetail> movieList = new ArrayList<MovieDetail>();
                Class.forName("com.mysql.jdbc.Driver");
                Connection myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/moviedb", "root" , "");
                ResultSet rs = null;
                Statement myStmt = null;
                String searchType = request.getParameter("movcat");
                
                if(searchType.equals("srchtitle")) {
                try {
                    
                   String srchtext = request.getParameter("srchmovie");
                   
                   myStmt = myConn.createStatement();
                   String query = "Select * from movie_details where movie_title ='" + srchtext + "'";
                   rs = myStmt.executeQuery(query);
                   while (rs.next()) {
                MovieDetail md = new MovieDetail();
                md.setTitle(rs.getString("movie_title"));
                md.setActor(rs.getString("lead_actor"));
                md.setActress(rs.getString("lead_actress"));
                md.setGenre(rs.getString("genre"));
                md.setYear(rs.getInt("year"));
                movieList.add(md);
                
            }
                request.setAttribute("movieList", movieList);
                RequestDispatcher rd = request.getRequestDispatcher("display.jsp");
                rd.forward(request, response);
                }
                
                catch (SQLException ex) {
            Logger.getLogger(MyMovieServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
                
                }  else if(searchType.equals("srchact")) {
                try {
                    
                   String srchtext = request.getParameter("srchmovie");
                   
                   myStmt = myConn.createStatement();
                   String query = "Select * from movie_details where lead_actor ='" + srchtext + "'";
                   rs = myStmt.executeQuery(query);
                   while (rs.next()) {
                MovieDetail md = new MovieDetail();
                md.setTitle(rs.getString("movie_title"));
                md.setActor(rs.getString("lead_actor"));
                md.setActress(rs.getString("lead_actress"));
                md.setGenre(rs.getString("genre"));
                md.setYear(rs.getInt("year"));
                movieList.add(md);
                
            }
                request.setAttribute("movieList", movieList);
                request.setAttribute("srchtext", srchtext);
                RequestDispatcher rd = request.getRequestDispatcher("display.jsp");
                rd.forward(request, response);
                }
                
                catch (SQLException ex) {
            Logger.getLogger(MyMovieServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
                
                }  else if(searchType.equals("srchactr")) {
                try {
                    
                   String srchtext = request.getParameter("srchmovie");
                   
                   myStmt = myConn.createStatement();
                   String query = "Select * from movie_details where lead_actress ='" + srchtext + "'";
                   rs = myStmt.executeQuery(query);
                   while (rs.next()) {
                MovieDetail md = new MovieDetail();
                md.setTitle(rs.getString("movie_title"));
                md.setActor(rs.getString("lead_actor"));
                md.setActress(rs.getString("lead_actress"));
                md.setGenre(rs.getString("genre"));
                md.setYear(rs.getInt("year"));
                movieList.add(md);
                
            }
                request.setAttribute("movieList", movieList);
                RequestDispatcher rd = request.getRequestDispatcher("display.jsp");
                rd.forward(request, response);
                }
                
                catch (SQLException ex) {
            Logger.getLogger(MyMovieServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
                
                }  
                
            }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MyMovieServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(MyMovieServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MyMovieServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(MyMovieServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
